﻿Build Date: 2026-07-14 13:27:42
Stock No: 6253100000
Version: V00R00
Core: V01R04
