﻿============================================================
                   BUILD COMPLETE
============================================================

Build Date:
  2026-06-15 13:21:18

Version Info:
  Stock No:       6253100000
  Stock Version:  V00R00
  Core Version:   V00R48

Generated Files:
  1. Application; Original file:        RF_6253100000_V00R00_V00R48_crc_csum.hex
  2. Factory; OTA function (Full):      RF_6253100000_V00R00_BV00R48_crc_csum.hex
  3. OTA Ready; OTA Upload (HEX):       RF_6253100000_V00R00_OV00R48_crc_csum.hex
  4. OTA Ready; OTA Upload (BIN):       RF_6253100000_V00R00_OV00R48_crc_csum.bin

File Sizes:
  Original:      495.88 KB
  Application:   571.08 KB (CRC32 + Checksum)
  Factory:       609.58 KB (Bootloader + Application)
  OTA HEX:       570.38 KB (Metadata prepended)
  OTA BIN:       237 KB (Binary format)

============================================================
