﻿============================================================
                   BUILD COMPLETE
============================================================

Build Date:
  2026-06-09 10:58:32

Version Info:
  Stock No:       6133102607
  Stock Version:  V00R11
  Core Version:   V00R53

Generated Files:
  1. Application; Original file:        RF_6133102607_V00R11_V00R53_crc_csum.hex
  2. Factory; OTA function (Full):      RF_6133102607_V00R11_BV00R53_crc_csum.hex
  3. OTA Ready; OTA Upload (HEX):       RF_6133102607_V00R11_OV00R53_crc_csum.hex
  4. OTA Ready; OTA Upload (BIN):       RF_6133102607_V00R11_OV00R53_crc_csum.bin

File Sizes:
  Original:      483.87 KB
  Application:   571.08 KB (CRC32 + Checksum)
  Factory:       609.58 KB (Bootloader + Application)
  OTA HEX:       570.38 KB (Metadata prepended)
  OTA BIN:       237 KB (Binary format)

============================================================
